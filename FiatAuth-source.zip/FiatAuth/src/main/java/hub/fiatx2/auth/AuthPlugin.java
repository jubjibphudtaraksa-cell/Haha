package hub.fiatx2.auth;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.io.File;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class AuthPlugin extends JavaPlugin implements Listener {

    private static final int MIN_LEN = 4;
    private static final int MAX_FAILS = 5;
    private static final long TIMEOUT_MS = 60_000L;

    private final Set<UUID> authed = ConcurrentHashMap.newKeySet();
    private final Map<UUID, Integer> fails = new HashMap<>();
    private final Map<UUID, Long> joinTime = new HashMap<>();
    private final SecureRandom random = new SecureRandom();

    private File file;
    private YamlConfiguration data;

    @Override
    public void onEnable() {
        file = new File(getDataFolder(), "passwords.yml");
        getDataFolder().mkdirs();
        data = YamlConfiguration.loadConfiguration(file);
        Bukkit.getPluginManager().registerEvents(this, this);

        // รองรับ /reload
        for (Player p : Bukkit.getOnlinePlayers()) joinTime.put(p.getUniqueId(), System.currentTimeMillis());

        // แสดงข้อความกลางจอซ้ำ + เช็คหมดเวลา
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            long now = System.currentTimeMillis();
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!locked(p)) continue;
                showPrompt(p);
                Long t = joinTime.get(p.getUniqueId());
                if (t != null && now - t > TIMEOUT_MS) {
                    p.kick(Component.text("หมดเวลา! กรุณา login ภายใน 60 วินาที", NamedTextColor.RED));
                }
            }
        }, 20L, 40L);
    }

    // ---------- helpers ----------

    private boolean locked(Player p) {
        return !authed.contains(p.getUniqueId());
    }

    private boolean isRegistered(UUID id) {
        return data.contains("users." + id);
    }

    private void showPrompt(Player p) {
        String msg = isRegistered(p.getUniqueId())
                ? "/login <รหัสผ่าน>"
                : "/register <ตั้งรหัส> <ยืนยันรหัส>";
        p.showTitle(Title.title(
                Component.text(msg, NamedTextColor.YELLOW),
                Component.empty(),
                Title.Times.times(Duration.ZERO, Duration.ofSeconds(3), Duration.ZERO)));
    }

    private String hash(String pass, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(pass.toCharArray(), salt, 65536, 256);
        byte[] h = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        return Base64.getEncoder().encodeToString(h);
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException e) {
            getLogger().severe("บันทึก passwords.yml ไม่ได้: " + e.getMessage());
        }
    }

    private void doAuth(Player p) {
        authed.add(p.getUniqueId());
        fails.remove(p.getUniqueId());
        joinTime.remove(p.getUniqueId());
        p.clearTitle();
    }

    // ---------- commands ----------

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }
        UUID id = p.getUniqueId();

        if (cmd.getName().equalsIgnoreCase("register")) {
            if (authed.contains(id)) {
                p.sendMessage(Component.text("คุณล็อกอินอยู่แล้ว", NamedTextColor.RED));
                return true;
            }
            if (isRegistered(id)) {
                p.sendMessage(Component.text("คุณสมัครแล้ว ใช้ /login <รหัสผ่าน>", NamedTextColor.RED));
                return true;
            }
            if (args.length != 2) {
                p.sendMessage(Component.text("ใช้: /register <ตั้งรหัส> <ยืนยันรหัส>", NamedTextColor.RED));
                return true;
            }
            if (!args[0].equals(args[1])) {
                p.sendMessage(Component.text("รหัสผ่านไม่ตรงกัน", NamedTextColor.RED));
                return true;
            }
            if (args[0].length() < MIN_LEN) {
                p.sendMessage(Component.text("รหัสผ่านต้องยาวอย่างน้อย " + MIN_LEN + " ตัว", NamedTextColor.RED));
                return true;
            }
            try {
                byte[] salt = new byte[16];
                random.nextBytes(salt);
                data.set("users." + id + ".salt", Base64.getEncoder().encodeToString(salt));
                data.set("users." + id + ".hash", hash(args[0], salt));
                data.set("users." + id + ".name", p.getName());
                save();
            } catch (Exception e) {
                p.sendMessage(Component.text("เกิดข้อผิดพลาด ลองใหม่อีกครั้ง", NamedTextColor.RED));
                return true;
            }
            doAuth(p);
            p.sendMessage(Component.text("สมัครสำเร็จ! ยินดีต้อนรับ", NamedTextColor.GREEN));
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("login")) {
            if (authed.contains(id)) {
                p.sendMessage(Component.text("คุณล็อกอินอยู่แล้ว", NamedTextColor.RED));
                return true;
            }
            if (!isRegistered(id)) {
                p.sendMessage(Component.text("ยังไม่ได้สมัคร ใช้ /register <ตั้งรหัส> <ยืนยันรหัส>", NamedTextColor.RED));
                return true;
            }
            if (args.length != 1) {
                p.sendMessage(Component.text("ใช้: /login <รหัสผ่าน>", NamedTextColor.RED));
                return true;
            }
            try {
                byte[] salt = Base64.getDecoder().decode(data.getString("users." + id + ".salt", ""));
                byte[] real = Base64.getDecoder().decode(data.getString("users." + id + ".hash", ""));
                byte[] given = Base64.getDecoder().decode(hash(args[0], salt));
                if (MessageDigest.isEqual(real, given)) {
                    doAuth(p);
                    p.sendMessage(Component.text("เข้าสู่ระบบสำเร็จ!", NamedTextColor.GREEN));
                } else {
                    int f = fails.merge(id, 1, Integer::sum);
                    if (f >= MAX_FAILS) {
                        p.kick(Component.text("ใส่รหัสผิดเกินกำหนด", NamedTextColor.RED));
                    } else {
                        p.sendMessage(Component.text("รหัสผ่านผิด (" + f + "/" + MAX_FAILS + ")", NamedTextColor.RED));
                    }
                }
            } catch (Exception e) {
                p.sendMessage(Component.text("เกิดข้อผิดพลาด ลองใหม่อีกครั้ง", NamedTextColor.RED));
            }
            return true;
        }
        return false;
    }

    // ---------- join / quit ----------

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        authed.remove(p.getUniqueId());
        joinTime.put(p.getUniqueId(), System.currentTimeMillis());
        showPrompt(p);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        authed.remove(id);
        fails.remove(id);
        joinTime.remove(id);
    }

    // ---------- restrictions ----------

    @EventHandler(priority = EventPriority.LOWEST)
    public void onMove(PlayerMoveEvent e) {
        if (!locked(e.getPlayer())) return;
        var f = e.getFrom();
        var t = e.getTo();
        if (t == null) return;
        // ขยับตำแหน่ง = ดึงกลับ (หมุนหัวได้)
        if (f.getX() != t.getX() || f.getY() != t.getY() || f.getZ() != t.getZ()) {
            var back = f.clone();
            back.setYaw(t.getYaw());
            back.setPitch(t.getPitch());
            e.setTo(back);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommandPre(PlayerCommandPreprocessEvent e) {
        if (!locked(e.getPlayer())) return;
        String cmd = e.getMessage().substring(1).split(" ")[0].toLowerCase();
        if (cmd.startsWith("minecraft:")) cmd = cmd.substring(10);
        if (cmd.equals("login") || cmd.equals("register")) return;
        e.setCancelled(true);
        e.getPlayer().sendMessage(Component.text("กรุณา login / register ก่อน", NamedTextColor.RED));
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteract(PlayerInteractEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onBreak(BlockBreakEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPlace(BlockPlaceEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDrop(PlayerDropItemEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && locked(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInvClick(InventoryClickEvent e) {
        if (e.getWhoClicked() instanceof Player p && locked(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInvOpen(InventoryOpenEvent e) {
        if (e.getPlayer() instanceof Player p && locked(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && locked(p)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onTarget(EntityTargetEvent e) {
        if (e.getTarget() instanceof Player p && locked(p)) e.setCancelled(true);
    }
}
